package pt.psoft.g1.psoftg1;

public class TestConfig {



}